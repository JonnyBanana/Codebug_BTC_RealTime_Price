from codebug_tether.core import (CodeBug,
                                 IO_DIGITAL_OUTPUT,
                                 IO_DIGITAL_INPUT,
                                 IO_ANALOGUE_INPUT,
                                 IO_PWM_OUTPUT,
                                 T2_PS_1_1,
                                 T2_PS_1_4,
                                 T2_PS_1_16,
                                 scale)
