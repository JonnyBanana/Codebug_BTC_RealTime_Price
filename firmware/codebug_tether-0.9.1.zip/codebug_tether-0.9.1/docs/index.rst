Welcome to CodeBug Tether's documentation!
==============================================

The codebug_tether Python module provides classes for
interacting with CodeBug over USB Serial.

Links:
    - `The CodeBug Website <http://www.codebug.org.uk>`_
    - `CodeBug Activity: "Tethering CodeBug with Python" <http://www.codebug.org.uk/learn/activity/66/tethering-codebug-with-python/>`_

Contents:

.. toctree::
   :maxdepth: 2

   codebug_tether
   installation
   example


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

